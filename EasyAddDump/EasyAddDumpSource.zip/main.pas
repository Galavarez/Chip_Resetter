unit main;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, ExtCtrls,
  EditBtn, CheckLst, ComboEx, Buttons, LazFileUtils, Clipbrd;

type

  { TFormMain }

  TFormMain = class(TForm)
    BitBtn_ClipboardDump: TBitBtn;
    BitBtn_ClipboardDataBase: TBitBtn;
    BitBtn_SelectDump: TBitBtn;
    ComboBox_Pinout: TComboBox;
    ComboBox_Page: TComboBox;
    ComboBox_SizeChip: TComboBox;
    ComboBox_Brand: TComboBox;
    ComboBox_Subprogram: TComboBox;
    GroupBox1: TGroupBox;
    GroupBox2: TGroupBox;
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    Label4: TLabel;
    Label5: TLabel;
    LabeledEdit_SizeDump: TLabeledEdit;
    LabeledEdit_DumpName: TLabeledEdit;
    LabeledEdit_LcdText: TLabeledEdit;
    LabeledEdit_PathInDump: TLabeledEdit;
    Memo_Dump: TMemo;
    Memo_DataBase: TMemo;
    OpenDialog_File: TOpenDialog;
    procedure BitBtn_ClipboardDataBaseClick(Sender: TObject);
    procedure BitBtn_ClipboardDumpClick(Sender: TObject);
    procedure BitBtn_SelectDumpClick(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure LabeledEdit_DumpNameChange(Sender: TObject);
    procedure LabeledEdit_LcdTextChange(Sender: TObject);
    procedure ComboBox_DataBaseChange(Sender: TObject);
  private

    procedure OpenBinFile(PathToFile: String);
    procedure OpenHexFile(PathToFile: String);
    procedure ViewCode(Sender: TObject);
    procedure ViewDump(Sender: TObject);
    procedure ViewLcd(Sender: TObject);

  public

  end;

var
  FormMain: TFormMain;
  GlobalArrayByte : Array of Byte;
  GlobalArrayString : Array of String;

implementation

{$R *.lfm}

{ TFormMain }


// Загружаем из txt названия
procedure TFormMain.FormShow(Sender: TObject);
begin
  ComboBox_Brand.Items.LoadFromFile('.\setting\brand.txt');
  ComboBox_Page.Items.LoadFromFile('.\setting\page.txt');
  ComboBox_Pinout.Items.LoadFromFile('.\setting\pinout.txt');
  ComboBox_SizeChip.Items.LoadFromFile('.\setting\memory.txt');
  ComboBox_Subprogram.Items.LoadFromFile('.\setting\subprogram.txt');
end;

// Выбираем дамп
procedure TFormMain.BitBtn_SelectDumpClick(Sender: TObject);
begin
  if OpenDialog_File.Execute then
  begin
    // Чистка формы
    LabeledEdit_PathInDump.Clear;
    LabeledEdit_DumpName.Clear;
    LabeledEdit_LcdText.Clear;
    LabeledEdit_SizeDump.Clear;
    Memo_Dump.Clear;
    ComboBox_Brand.Text:='';
    ComboBox_Page.Text:='';
    ComboBox_Pinout.Text:='';
    ComboBox_SizeChip.Text:='';
    ComboBox_Subprogram.Text:='';
    Memo_DataBase.Clear;


    // Показываем путь к дампу
    LabeledEdit_PathInDump.Text := OpenDialog_File.FileName;

    // Если BIN
    if LowerCase(ExtractFileExt(OpenDialog_File.FileName)) = '.bin' then begin
      OpenBinFile(OpenDialog_File.FileName);
    // Если HEX
    end else if LowerCase(ExtractFileExt(OpenDialog_File.FileName)) = '.hex' then begin
      OpenHexFile(OpenDialog_File.FileName);
    end;

    // Записываем базовое имя
    LabeledEdit_DumpName.Text := 'dump_name'; //LazFileUtils
    LabeledEdit_LcdText.Text := 'lcd_text';

    // Записываем размер массива дампа
    LabeledEdit_SizeDump.Text:= IntToStr( Length(GlobalArrayString) );

    // Чистим Memo
    Memo_Dump.Clear;

    // Просмотр кода
    ViewLcd(Self);
    ViewDump(Self);
    ViewCode(Self);
  end;
end;


// Открываем BIN и запихиваем в GlobalArrayString
procedure TFormMain.OpenBinFile(PathToFile: String);
var
  FileStream: TFileStream;
  i: integer;
begin
  //ShowMessage('bin file');
  FileStream := TFileStream.Create(PathToFile, fmOpenRead);
  SetLength(GlobalArrayByte, FileStream.Size);
  SetLength(GlobalArrayString, FileStream.Size);
  FileStream.Read(GlobalArrayByte[0], FileStream.Size);
  FileStream.Free;

  // Переводим bin to hex to string
  for i:=0 to Length(GlobalArrayByte)-1 do
  begin
    GlobalArrayString[i] := GlobalArrayByte[i].ToHexString;
  end;
end;

// Открываем HEX и запихиваем в GlobalArrayString
procedure TFormMain.OpenHexFile(PathToFile: String);
var
  CountLines, Stroka, NumByte: Integer;
begin
  // Загружаем файл в Memo
  Memo_Dump.Lines.LoadFromFile(PathToFile);
  // Удаляем не нужные строки (это сроки которые не начинаются на :10)
  for CountLines:=0 to Memo_Dump.Lines.Count-1 do begin
    if Pos(':10', Memo_Dump.Lines[CountLines]) = 0 then Memo_Dump.Lines.Delete(CountLines);
  end;
  // Получаем количество байт в массиве (строки умножаем на 16)
  SetLength(GlobalArrayString, Memo_Dump.Lines.Count * 16);
  // Записываем в массив данные
  for Stroka:=0 to Memo_Dump.Lines.Count-1 do begin
    for NumByte:=0 to 15 do begin
      GlobalArrayString[(Stroka*16)+NumByte] := Memo_Dump.Lines[Stroka][10+NumByte*2] + Memo_Dump.Lines[Stroka][11+NumByte*2];
    end;
  end;
end;

// LCD
procedure TFormMain.ViewLcd(Sender: TObject);
var
  LcdVar, LcdText: TCaption;
begin
  LcdVar := 'lcd_' + LabeledEdit_DumpName.Text;
  LcdText := LabeledEdit_LcdText.Text;
  Memo_Dump.Lines[0] := 'const PROGMEM char ' + LcdVar + '[] = { "' + LcdText + '" };' ;
end;

// DUMP
procedure TFormMain.ViewDump(Sender: TObject);
var
  DumpVar: TCaption;
begin
  DumpVar := 'dump_' + LabeledEdit_DumpName.Text;
  Memo_Dump.Lines[1] := 'const PROGMEM byte ' + DumpVar + '[' + LabeledEdit_SizeDump.Text + '] = {' ;
end;

// CODE
procedure TFormMain.ViewCode(Sender: TObject);
var
  NumberByte: Integer;
begin
  for NumberByte:=0 to StrToInt(LabeledEdit_SizeDump.Text) - 1 do
  begin
    // Каждые 16 байт делаем переход на новую строку
    if (NumberByte <> 0) and ((NumberByte mod 16) = 0) then
    begin
      Memo_Dump.Text := Memo_Dump.Text + #13#10;
    end;

    // Если байт последний то не добавляем запятую
    if NumberByte = (StrToInt(LabeledEdit_SizeDump.Text) - 1) then
      begin
        Memo_Dump.Text := Memo_Dump.Text + '0x' + GlobalArrayString[NumberByte] ;
      end else begin
        Memo_Dump.Text := Memo_Dump.Text + '0x' + GlobalArrayString[NumberByte] + ', ';
      end;
  end;
  // Добавляем в конец
  Memo_Dump.Lines.Add( '};' );

  // Ставим Курсор на 0 строку
  Memo_Dump.SelStart := 0;
end;

// Меняем LCD и Dump и ComboBox
procedure TFormMain.LabeledEdit_DumpNameChange(Sender: TObject);
begin
  ViewLcd(Self);
  ViewDump(Self);
  ComboBox_DataBaseChange(Self);
end;

// Меняем LCD
procedure TFormMain.LabeledEdit_LcdTextChange(Sender: TObject);
begin
  ViewLcd(Self);
end;

///////////////
// DATA BASE //
///////////////

procedure TFormMain.ComboBox_DataBaseChange(Sender: TObject);
var
  VarBrand, VarPage, VarPinout, VarLcd, VarDump, VarSubprogram,
    VarSize: TCaption;
begin
  Memo_DataBase.Clear;
  VarBrand := '{ ' + ComboBox_Brand.Text + ' , ';
  VarPage := ComboBox_Page.Text + ' , ';
  VarPinout := ComboBox_Pinout.Text + ' , ';
  VarLcd := 'lcd_' + LabeledEdit_DumpName.Text + ' , ';
  VarDump := 'dump_' + LabeledEdit_DumpName.Text + ' , ';
  VarSize := ComboBox_SizeChip.Text + ', ';
  VarSubprogram := ComboBox_Subprogram.Text + ' }';
  Memo_DataBase.Lines[0] := VarBrand + VarPage + VarPinout + VarLcd  + VarDump + VarSize + VarSubprogram;
end;


// Копируем в буфер MEMO DUMP
procedure TFormMain.BitBtn_ClipboardDumpClick(Sender: TObject);
begin
  Clipboard.AsText:=Memo_Dump.Text;
end;

// Копируем в буфер MEMO DATA BASE
procedure TFormMain.BitBtn_ClipboardDataBaseClick(Sender: TObject);
begin
  Clipboard.AsText:=Memo_DataBase.Text;
end;



end.

