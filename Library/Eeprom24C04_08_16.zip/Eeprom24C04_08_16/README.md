24C04-08-16
===========

Arduino library for 24C04/08/16 serial EEPROM
